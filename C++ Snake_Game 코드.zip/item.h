#pragma once

#include "variable.h"
#include "struct.h"

void generateItem(int map[HEIGHT][WIDTH], const Snake& snake, int type);